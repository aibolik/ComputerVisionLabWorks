%% Lab2 Assignment
% Student: *Bob Godgivenson @ EN4-Z-01* 
%%
% Show all your play here...

