%% Lab3 Assignment
% Student: *Bob The Builder @ EN3-A-04* 
%%
% Play here...