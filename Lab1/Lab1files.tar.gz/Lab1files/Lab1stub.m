%% Lab1 Assignment
% Student: *Andrey Godgivenson @ EN4-Z-01* 
%%
% Your comments...
%% Question 1
% What a heck is wrong with *imhist*?
% Well, it's color is strange...
%% imxist code
%
% <include> imxist.m </include>
%
%% Demo1 : Your Title for Demo1
% Your comments for Demo1
A = imread('peppers.png');
imxist(A(:,:,1));
%% Demo2 : Your Title for Demo2
% Your comments for Demo2
imxist(A(:,:,2));
%% DemoN : Your Title for DemoN
% Your comments for DemoN
imxist(A(:,:,3));