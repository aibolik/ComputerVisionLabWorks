function imxist(I)
%IMHIST Display histogram of image data.
% write your code here
    h = xist(I);
    bar(h);
end
